from turtle import Turtle
STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280


class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("turtle")
        self.penup()
        self.goto(STARTING_POSITION)
        self.tilt(90)
    def up(self):
        newy = self.ycor() + MOVE_DISTANCE
        self.goto(x=self.xcor(),y=newy)
    def left(self):
        newx = self.xcor() - MOVE_DISTANCE
        self.goto(x=newx,y=self.ycor())
    def right(self):
        newx = self.xcor() + MOVE_DISTANCE
        self.goto(x=newx,y=self.ycor())