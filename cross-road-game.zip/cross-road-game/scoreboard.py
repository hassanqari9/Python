from turtle import Turtle
FONT = ("Courier", 14, "normal")


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.level = 1
        self.score()
    def score(self):
        self.hideturtle()
        self.penup()
        self.goto(-290, 270)
        self.write(f"Level: {self.level}",align="left",font=FONT)
    def level_up(self):
        self.level += 1
    def game_over(self):
        self.hideturtle()
        self.penup()
        self.goto(0,0)
        self.write("Game Over", align="center", font=FONT)

