from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

menu = Menu()
coffeemaker = CoffeeMaker()
moneymachine = MoneyMachine()
  
is_on = True
while is_on:
    
    choice=input("​What would you like?:")
    if choice == 'menu':
      m = menu.get_items()
      print(m) 
      order_name = input("Which one would you like to have?:")
      drink = menu.find_drink(order_name)
      if coffeemaker.is_resource_sufficient(drink):
        cost = drink.cost
        v=moneymachine.make_payment(cost)
        if v is True:
          coffeemaker.make_coffee(drink)
    elif choice == "off":
      is_on = False
    elif choice == "report":
      coffeemaker.report()
      moneymachine.report()
    
    