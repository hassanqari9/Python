from tkinter import *
from tkinter import messagebox
from random import randint, choice, shuffle
import pyperclip
import json
def find_password():
  one = input1.get()
  try:
    with open("Passwords.json","r") as file:
      data = json.load(file)
    messagebox.showinfo(title="Website password", message=f'Website:{one} Email:{data[one]["email"]} Password:{data[one]["password"]}')
    pyperclip.copy(data[one]["password"])
  except FileNotFoundError:
    messagebox.showinfo(title="error", message="No data file found")
  except KeyError:
    messagebox.showinfo(title="error", message=f"{one} data not found")
def password_generator():
  letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

  # for char in range(nr_letters):
  #   password_list.append(random.choice(letters))
  password_letters = [choice(letters) for char in range(randint(8, 10))]
  # for char in range(nr_symbols):
  #   password_list += random.choice(symbols)
  password_symbols =[choice(symbols) for char in range(randint(2, 4))]
  # for char in range(nr_numbers):
  #   password_list += random.choice(numbers)
  password_numbers =[choice(numbers) for char in range(randint(2, 4))]

  password_list = password_letters + password_symbols + password_numbers
  shuffle(password_list)

  # password = ""
  # for char in password_list:
  #   password += char
  password = "".join(password_list)
  input3.insert(0,password)
  pyperclip.copy(password)


def save():
    one = input1.get()
    two = input2.get()
    three = input3.get()
    new_data = {
        one:{
            "email" : two,
            "password" : three
        }
    }
    if len(one) == 0 or len(two) == 0 or len(three) == 0:
        messagebox.showerror(title="ERROR", message='ENTRY LEFT EMPTY')
    else:
        try:
            with open("Passwords.json","r") as f:
                data = json.load(f)
        except FileNotFoundError:
            with open("Passwords.json","w") as f:
                json.dump(new_data,f,indent=4)
        else:
            data.update(new_data)
            with open("Passwords.json","w") as f:
                json.dump(data,f,indent=4)
        finally:
            input1.delete(0,'end')
            input3.delete(0,'end')



window = Tk()
window.title("Password Generator")
window.minsize(width=200,height=200)
window.configure(padx=50,pady=50)

canvas = Canvas(width=200,height=200)
lock_img = PhotoImage(file ="logo.png")
canvas.create_image(100,100,image=lock_img)
canvas.grid(column=1,row=0)

website=Label(text="Website:")
website.grid(column=0,row=1)
email=Label(text="Email/Username:")
email.grid(column=0,row=2)
password=Label(text="Password:")
password.grid(column=0,row=3)

input1 = Entry(width=20)
input1.grid(column=1,row=1)
input2 = Entry(width=38)
input2.grid(column=1,row=2,columnspan=2)
input3 = Entry(width=20)
input3.grid(column=1,row=3,columnspan=1)
button0= Button(text="Search",width=14,command=find_password)
button0.grid(column=2,row=1)
button1= Button(text="Generate Password",width=14,command=password_generator)
button1.grid(column=2,row=3)
button2= Button(text="Add",width=37,command=save)
button2.grid(column=1,row=4,columnspan=2)





window.mainloop()